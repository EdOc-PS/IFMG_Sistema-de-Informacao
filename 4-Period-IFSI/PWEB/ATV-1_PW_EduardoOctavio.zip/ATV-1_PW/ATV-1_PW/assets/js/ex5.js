const btn = document.getElementById("btn");
const p = document.getElementById("soma")
let resul = 1;


btn.addEventListener("click", () => {
    p.innerText = resul++;
})