const btn = document.getElementById("btn");
const p = document.getElementById("ocultar")

btn.addEventListener("click", () => {
    p.classList.toggle("hidden")
    if(btn.innerText === "Ocultar"){
        btn.innerText = "Mostrar"
    }else{
        btn.innerText = "Ocultar"
    }
   
})