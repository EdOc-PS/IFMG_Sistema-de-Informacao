const btn = document.getElementById("btn");
const input = document.querySelector("input")
const list = document.getElementById("list");


btn.addEventListener("click", () => {
    const conteudoLI = input.value.trim()
    const item = document.createElement("li");
    item.textContent = conteudoLI;
    list.appendChild(item);
    input.value = "";

})