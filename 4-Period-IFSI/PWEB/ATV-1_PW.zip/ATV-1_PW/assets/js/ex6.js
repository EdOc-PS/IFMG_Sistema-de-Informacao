const btn = document.getElementById("btn");
const body = document.querySelector("body");
let resul = 0;


btn.addEventListener("click", () => {
    body.classList.toggle("dark")
})