const btn = document.getElementById("btn");
const body = document.querySelector("body")


function gerarCor() {
    const r = Math.floor(Math.random() * 256); 
    const g = Math.floor(Math.random() * 256); 
    const b = Math.floor(Math.random() * 256);
    return `rgb(${r}, ${g}, ${b})`;
  }

btn.addEventListener("click", () => {
    let cor = gerarCor();
    body.style.backgroundColor = cor;
})