const btn = document.getElementById("btn");
const input = document.querySelector("input")
const list = document.getElementById("list");
const conteudoLI = input.value.trim()

btn.addEventListener("click", () => {
    const item = document.createElement("li");
    item.textContent = conteudoLI;
    list.appendChild(item);
    input.value = "";

})